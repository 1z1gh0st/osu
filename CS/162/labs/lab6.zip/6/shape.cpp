#include "shape.h"

Shape::Shape(string _name_, string _color_) {
    name = _name_;
    color = _color_;
}

float Shape::area() {
    return 0;
}