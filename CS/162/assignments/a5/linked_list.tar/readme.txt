This program is a linked list.
The test runs as required on the program page.
I made a template class for linked_list, hence the lack of file seperation.
The prime calculation does take a while on very large numbers,
so be prepared to wait if you insert humoungus chungus values.