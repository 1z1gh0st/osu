#include "tiger.h"

Tiger::Tiger() {
    cost = 12000;
    monthly_revenue = cost / 10;
    birth_rate = 3;  
    animal_type = "Tiger";
}
