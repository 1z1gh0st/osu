#include "tiger.h"
#include "animal.h"
#include "bear.h"
#include "sea_lion.h"
#include "zoo.h"

using namespace std;

int main() {
    Zoo muh_zoo;
    while (muh_zoo.get_money() > 0) {
        muh_zoo.iterate_month();
        if (muh_zoo.get_month() == 20) {
            break;
        }
    }
    return 0;
}