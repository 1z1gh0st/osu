#include "animal.h"

using std::cout;

Animal::Animal() {
    animal_type = "type_not_set";
    age = 0;
    monthly_food_cost = ((rand() % 40) + 80);
}

bool Animal::is_baby() const {
    return (age < 6) ? true : false;
}

bool Animal::is_adult() const {
    return (age >= 48) ? true : false;
}

void Animal::print() const {
    if (is_baby()) {
        cout << "Baby ";
    } else if (!is_adult()) {
        cout << "Adolescent ";
    } else {
        cout << "Adult ";
    }
    cout << animal_type;
}

int Animal::get_age() const {
    return age;
}

int Animal::get_birth_rate() const {
    return birth_rate;
}

long Animal::get_cost() const {
    return cost;
}

long Animal::get_monthly_food_cost() const {
    return monthly_food_cost;
}

long Animal::get_monthly_revenue() const {
    return (age < 6) ? monthly_revenue * 2 : monthly_revenue;
}

string Animal::get_animal_type() const {
    return animal_type;
}

void Animal::iterate_month() {
    age++;
    monthly_food_cost += (((rand() % 40) - 20.0) / 100.0) * monthly_food_cost;
}

void Animal::set_age(int _age_) {
    age = _age_;
}