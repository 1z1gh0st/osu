#include "zoo.h"
#include <iostream>
#include <cstdlib>

using std::cout;
using std::endl;
using std::string;

Zoo::Zoo() {
    array = new Animal* [0];
    array_length = 0;
    month = 0;
    special_event = 0;
    money = 100000;
}

Zoo::~Zoo() {
    cout << "Destructor called" << endl;
    for (int i = 0; i < array_length; i++) {
        cout << array[i]->get_animal_type() << endl;
        cout << "i = " << i << endl;
        delete (array[i]);
    }
    delete [] array;
    cout << "Zoo destroyed" << endl;
}

Animal Zoo::get_animal_at(int i) const {
    if (i >= array_length || i < 0) {
        cout << "ERROR: Attempting to get animal at invalid index i=" << i << endl;
        exit(1);    // Error handler for bad idicies
    } else {
        return *array[i];
    }
}

int Zoo::get_array_length() const {
    return array_length;
}

int Zoo::get_month() const {
    return month;
}

int Zoo::get_special_event() const {
    return special_event;
}

long Zoo::get_money() const {
    return money;
}

void Zoo::iterate_month() {
    month++;
    for (int i = 0; i < array_length; i++) {
        array[i]->iterate_month();
    }
    print_zoo_status();
    if (array_length > 0) {
        special_event_func();
        revenue();
        pay_food_cost();
    }
    allow_animal_purchase();
}

void Zoo::special_event_func() {
    // Special Event
    special_event = rand() % 4;
    int rand_animal_index = rand() % array_length;
    if (special_event == 0) {
        cout << "Sickness!!!" << endl;
        sickness(rand_animal_index);
    } else if (special_event == 1) {
        cout << "Babies!!!" << endl;
        reproduce(rand_animal_index);
    } else if (special_event == 2) {
        cout << "Attendance boom!!!" << endl;
    } else {
        cout << "No special event occured." << endl;
    }
}

void Zoo::sickness(int rand_animal_index) {
    // Random Animal Sickness
    int sickness_cost = array[rand_animal_index]->get_monthly_revenue() / 2;
    cout << "Your " << array[rand_animal_index]->get_animal_type() << " has gotten sick." << endl;
    if (money >= sickness_cost) {
        cout << "You pay $" << sickness_cost << ". " << endl;
        money -= sickness_cost;
    } else {
        cout << "Not enough funds availible. Your " << array[rand_animal_index]->get_animal_type() << " dies." << endl;
        remove_animal(rand_animal_index);
    }
}

void Zoo::reproduce(int rand_animal_index) {
    if (rand_animal_index >= array_length || rand_animal_index < 0) {
        cout << "ERROR: Random animal index out of range. Exiting program." << endl;
        exit(1);
    }
    // Random Animal Reproduction
    string type = array[rand_animal_index]->get_animal_type();
    int amount = array[rand_animal_index]->get_birth_rate();
    if (type == "Tiger") {
        Tiger *t = new Tiger();
        add_animal(t);
    } else if (type == "Bear") {
        Bear *b = new Bear();
        add_animal(b);
    } else {
        Sea_Lion *sl = new Sea_Lion();
        add_animal(sl);
    }
}

void Zoo::attendance_boom() {
    int sea_lion_count = 0;
    for (int i = 0; i < array_length; i++) {
        if (array[i]->get_animal_type() == "Sea_Lion") {
            money += rand() % 250 + 150;
        }
    }
}

void Zoo::add_animal(Animal *a) {
    Animal **temp_arr = new Animal* [array_length + 1];
    for (int i = 0; i < array_length; i++) {
        temp_arr[i] = array[i];
    }
    temp_arr[array_length] = a;
    array_length++;
    delete [] array;
    array = temp_arr;
}

void Zoo::remove_animal(int index) {
    if (array_length != 0) {
        Animal **temp_arr = new Animal* [array_length - 1];
        for (int i = 0; i < array_length; i++) {
            if (i < index) {
                temp_arr[i] = array[i];
            } else if (i == index) {
                continue;
            } else {
                temp_arr[i - 1] = array[i];
            }
        }
        // free_array();
        array = temp_arr;
        delete [] temp_arr;
        array_length--;
    } else {
        cout << "ERROR: trying to remove animal from empty array" << endl;
        exit(1);
    }
}

void Zoo::allow_animal_purchase() {
    for (int i = 0; i < 2; i++) {
        cout << "Would you like to purchase an animal? : " << endl;
        cout << "    1. Tiger ($12,000)" << endl;
        cout << "    2. Black Bear ($5,000)" << endl;
        cout << "    3. Sea Lion ($700)" << endl;
        cout << "    4. None" << endl;
        cout << ">> ";
        int animal_to_purchase_type = InputHandler::get_input_between(1, 4);
        if (animal_to_purchase_type == 1) {
            if (money >= 12000) {
                money -= 12000;
                Tiger *tiger = new Tiger;
                add_animal(tiger);
            } else {
                cout << "\nYou do not have enough funds to purchase this animal." << endl;
            }
        } else if (animal_to_purchase_type == 2) {
            if (money >= 5000) {
                money -= 5000;
                Bear *bear = new Bear;
                add_animal(bear);
            } else {
                cout << "\nYou do not have enough funds to purchase this animal." << endl;
            }
        } else if (animal_to_purchase_type == 3) {
            if (money >= 700) {
                money -= 700;
                Sea_Lion *sea_lion = new Sea_Lion;
                add_animal(sea_lion);
            } else {
                cout << "\nYou do not have enough funds to purchase this animal." << endl;
            }
        }
        if (animal_to_purchase_type != 4) {
            array[array_length - 1]->set_age(48);
        }
    }
}

void Zoo::revenue() {
    for (int i = 0; i < array_length; i++) {
        money += array[i]->get_monthly_revenue();
    }
}

void Zoo::pay_food_cost() {
    for (int i = 0; i < array_length; i++) {
        money -= array[i]->get_monthly_food_cost();
        if (money < 0) {
            cout << "Game over. No money" << endl;
            exit(0);
        }
    }
}

void Zoo::print_zoo_status() {
    cout << "--MONTH " << month << "--" << endl;
    cout << "Money : " << money << endl;
    cout << "Animals : " << endl;
    for (int i = 0; i < array_length; i++) {
        cout << "    " << array[i]->get_animal_type();
        cout << " : age = " << array[i]->get_age() << " months";
        cout << " : revenue = $" << array[i]->get_monthly_revenue();
        cout << " : food cost = $" << array[i]->get_monthly_food_cost() << endl;
    }
}
