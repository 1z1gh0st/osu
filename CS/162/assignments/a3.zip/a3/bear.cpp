#include "bear.h"

using std::cout;
using std::string;

Bear::Bear() {
    cost = 5000;
    monthly_revenue = cost / 10;
    birth_rate = 2;  
    animal_type = "Bear";
}

string Bear::get_animal_type() const {
    return "Bear";
}