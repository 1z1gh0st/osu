#ifndef BEAR_H
#define BEAR_H

#include "animal.h"
#include <iostream>

class Bear: public Animal {
    private:
        
    public:
        Bear();
        string get_animal_type() const;
};

#endif
