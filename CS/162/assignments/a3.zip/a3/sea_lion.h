#ifndef SEA_LION_H
#define SEA_LION_H

#include "animal.h"
#include <iostream>

class Sea_Lion: public Animal {
    private:
    public:
        Sea_Lion();
};

#endif