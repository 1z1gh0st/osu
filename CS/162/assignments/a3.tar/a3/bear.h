#ifndef BEAR_H
#define BEAR_H

#include "animal.h"
#include <iostream>

class Bear: public Animal {
    private:
        
    public:
        Bear();
};

#endif
