#ifndef ASSIGNMENT2_HEADER_H
#define ASSIGNMENT2_HEADER_H

#include <iostream>

using namespace std;

bool check_range(int, int, int);

bool is_capital(char);

bool is_even(int);

bool is_odd(int);

int equality_test(int, int);

bool float_is_equal(float, float, float);

bool is_int(string);

bool numbers_present(string);

bool letters_present(string);

bool contains_sub_string(string, string);

int word_count(string);

string to_upper(string);

string to_lower(string);

int get_int(string);

#endif