/***********************************************************
* Author: 
* Email: 
* Date Created: 
* Filename: bst.c
*
* Solution description: Implementation of a Binary Search Tree 
* that can store any arbitrary struct in its nodes.
************************************************************/
 

#include <stdlib.h>
#include <stdio.h>
#include <assert.h>
#include <string.h>
#include "bst.h"
#include "structs.h"

/* ************************************************************************
	Struct Node & BSTree
************************************************************************ */

struct Node
{
	TYPE value;
	struct Node* left;
	struct Node* right;
};

struct BSTree
{
	struct Node* root;
	int count;
};


/* ************************************************************************
	BST Functions
************************************************************************ */

struct BSTree* newBSTree() {
	// Allocate memory and set return initialized tree
	struct BSTree* result = (BSTree*)malloc(sizeof(BSTree));
	result->root = NULL;
	result->count = 0;
	return result;
}

void deleteBSTree(BSTree* myTree) {
	while (myTree->count > 0) {
		removeBSTree(myTree, minBSTree(myTree));
	}
	free(myTree);
}

int isEmptyBSTree(BSTree* myTree) {
	// Check if its empty by checking if count is 0 
	return (myTree->count == 0);
}

int sizeBSTree(BSTree* myTree) {
	return myTree->count;
}

void addBSTree(BSTree* myTree, TYPE value) {

	// Allocate memory for new node
	struct Node* newNode = (struct Node*)malloc(sizeof(struct Node));	
	newNode->value = value;
	newNode->left = NULL;
	newNode->right = NULL;

	// First insertion
	if (myTree->root == NULL) {
		myTree->root = newNode;
		myTree->count++;
	
	// Otherwise
	} else {
		struct Node* curr = myTree->root;
		struct Node* parent = curr;
		int c;
		while (curr != NULL) {
			parent = curr;
			c = compare(value, curr->value);
			if (c == -1) {
				curr = curr->left;
			} else if (c == 1) {
				curr = curr->right;
			} else { 
				break;
			}
		}
		if (curr == NULL) {
			if (c == -1) {
				parent->left = newNode;
			} else if (c == 1) {
				parent->right = newNode;
			}
			myTree->count++;
		} else {
			// Case where node already exists in tree
			free(newNode);
		}
	}
}

int containsBSTree(BSTree* myTree, TYPE value) {
	struct Node* curr = myTree->root;
	int c;
	while(curr != NULL) {
		c = compare(value, curr->value);
		if (c == -1) {
			curr = curr->left;
		} else if (c == 1) {
			curr = curr->right;
		} else {
			// Return 1 if val = curr->val
			return 1;
		}
	}
	// Return 0 otherwise
	return 0;
}

TYPE minBSTree(BSTree* myTree) {
	struct Node* curr = myTree->root;
	while (curr->left != NULL) {
		curr = curr->left;
	}
	// Go to left most node
	return curr->value;
}

TYPE maxBSTree(BSTree* myTree) {
	struct Node* curr = myTree->root;
	while (curr->right != NULL) {
		curr = curr->right;
	}
	// Go to right most node
	return curr->value;
}

void removeBSTree(BSTree *tree, TYPE value) {
	// Step 1: Find value in tree
	struct Node* curr = tree->root;
	struct Node* parent = NULL;
	int c, c_0 = 0;
	while (1) {
		c = compare(value, curr->value);
		if (c == -1) {
			c_0 = c;
			parent = curr;
			curr = curr->left;
		} else if (c == 1) {
			c_0 = c;
			parent = curr;
			curr = curr->right;
		} else {
			// We have found the value
			break;
		}
	}
	// Case 1: Curr is a leaf node
	if (curr->left == NULL && curr->right == NULL) {
		free(curr);
		curr = NULL;
		if (c_0 == -1) {
			parent->left = NULL;
		} else if (c_0 == 1) {
			parent->right = NULL;
		} else {
			tree->root = NULL;
		}
	}
	// Case 2: One subtree
	else if (curr->left == NULL || curr->right == NULL) {
		if (curr->left != NULL) {
			if (c_0 == -1) {
				parent->left = curr->left;
			} else if (c_0 == 1) {
				parent->right = curr->left;
			} else {
				tree->root = curr->left;
			}
		} else {
			if (c_0 == -1) {
				parent->left = curr->right;
			} else if (c_0 == 1) {
				parent->right = curr->right;
			} else {
				tree->root = curr->right;
			}
		}
		if (curr != NULL) {
			free(curr);
			curr = NULL;
		}
	}
	// Case 3: Both subtrees
	else {
		struct Node* rightMin = curr->right;
		while (rightMin->left != NULL) {
			rightMin = rightMin->left;
		}
		rightMin->left = curr->left;
		rightMin->right = curr->right;
		if (c_0 == -1) {
			parent->left = rightMin;
		} else if (c_0 == 1) {
			parent->right = rightMin;
		} else {
			tree->root = rightMin;
		}
		free(curr);
		curr = NULL;
	}
	tree->count--;
}

void _printSubTree(struct Node* n) {
	if (n == NULL) {
		return;
	} else {
		_printSubTree(n->left);
		print_type(n->value);
		_printSubTree(n->right);
	}
}

void printBSTree(BSTree* myTree) {
	_printSubTree(myTree->root);
}

